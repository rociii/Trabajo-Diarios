# Pruebas con Variables
print("\nTrabajos con variables\n")
a =2
b =3
c =4
d =5
suma= a+b
resta= d-c
multiplicación= a*d
división= a/c
print("La suma es", suma)
print("La resta es",resta)
print("La multipicación",multiplicación)
print("La división es",división)
print("La potencia es",a**10)
